"use client"

import type { ScanResultType, PortInfo } from "@/types/scan-types"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { CheckCircle2, AlertTriangle, Shield, Clock } from "lucide-react"

interface ScanResultsProps {
  results: ScanResultType
}

export function ScanResults({ results }: ScanResultsProps) {
  const { target, timestamp, scanDuration, openPorts, vulnerabilities, hostInfo } = results

  const getVulnerabilitySeverityColor = (severity: string) => {
    switch (severity.toLowerCase()) {
      case "critical":
        return "bg-red-500"
      case "high":
        return "bg-orange-500"
      case "medium":
        return "bg-yellow-500"
      case "low":
        return "bg-blue-500"
      default:
        return "bg-gray-500"
    }
  }

  const formatTimestamp = (timestamp: number) => {
    return new Date(timestamp).toLocaleString()
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <div>
            <CardTitle>Scan Results</CardTitle>
            <CardDescription>
              Target: {target} • Scanned on {formatTimestamp(timestamp)}
            </CardDescription>
          </div>
          <Badge variant="outline" className="flex items-center gap-1">
            <Clock className="h-3 w-3" />
            {scanDuration}ms
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <Accordion type="single" collapsible defaultValue="ports">
          <AccordionItem value="summary">
            <AccordionTrigger>Summary</AccordionTrigger>
            <AccordionContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="bg-muted rounded-lg p-4">
                  <div className="text-sm text-muted-foreground mb-1">Open Ports</div>
                  <div className="text-2xl font-bold">{openPorts.length}</div>
                </div>
                <div className="bg-muted rounded-lg p-4">
                  <div className="text-sm text-muted-foreground mb-1">Vulnerabilities</div>
                  <div className="text-2xl font-bold">{vulnerabilities.length}</div>
                </div>
                <div className="bg-muted rounded-lg p-4">
                  <div className="text-sm text-muted-foreground mb-1">Host Type</div>
                  <div className="text-2xl font-bold">{hostInfo.type || "Unknown"}</div>
                </div>
              </div>

              {hostInfo.os && (
                <div className="bg-muted rounded-lg p-4 mb-4">
                  <div className="text-sm text-muted-foreground mb-1">Operating System</div>
                  <div className="font-medium">{hostInfo.os}</div>
                </div>
              )}
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="ports">
            <AccordionTrigger>Open Ports ({openPorts.length})</AccordionTrigger>
            <AccordionContent>
              {openPorts.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Port</TableHead>
                      <TableHead>Service</TableHead>
                      <TableHead>State</TableHead>
                      <TableHead>Version</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {openPorts.map((port: PortInfo) => (
                      <TableRow key={port.port}>
                        <TableCell className="font-medium">{port.port}</TableCell>
                        <TableCell>{port.service || "Unknown"}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                            Open
                          </Badge>
                        </TableCell>
                        <TableCell>{port.version || "Unknown"}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-4 text-muted-foreground">No open ports detected</div>
              )}
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="vulnerabilities">
            <AccordionTrigger>Vulnerabilities ({vulnerabilities.length})</AccordionTrigger>
            <AccordionContent>
              {vulnerabilities.length > 0 ? (
                <div className="space-y-4">
                  {vulnerabilities.map((vuln, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-medium">{vuln.name}</h3>
                        <Badge className={getVulnerabilitySeverityColor(vuln.severity)}>{vuln.severity}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{vuln.description}</p>
                      {vuln.affectedPorts && vuln.affectedPorts.length > 0 && (
                        <div className="text-sm mb-2">
                          <span className="font-medium">Affected Ports: </span>
                          {vuln.affectedPorts.join(", ")}
                        </div>
                      )}
                      {vuln.recommendation && (
                        <div className="text-sm">
                          <span className="font-medium">Recommendation: </span>
                          {vuln.recommendation}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-4 text-muted-foreground">No vulnerabilities detected</div>
              )}
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="recommendations">
            <AccordionTrigger>Security Recommendations</AccordionTrigger>
            <AccordionContent>
              <div className="space-y-3">
                {openPorts.length > 0 && (
                  <div className="flex items-start gap-2">
                    <Shield className="h-5 w-5 text-orange-500 mt-0.5" />
                    <div>
                      <p className="font-medium">Close unnecessary ports</p>
                      <p className="text-sm text-muted-foreground">
                        Consider closing ports that are not required for your services to reduce attack surface.
                      </p>
                    </div>
                  </div>
                )}

                {vulnerabilities.length > 0 && (
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="h-5 w-5 text-red-500 mt-0.5" />
                    <div>
                      <p className="font-medium">Address identified vulnerabilities</p>
                      <p className="text-sm text-muted-foreground">
                        Prioritize fixing vulnerabilities based on their severity level.
                      </p>
                    </div>
                  </div>
                )}

                <div className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-500 mt-0.5" />
                  <div>
                    <p className="font-medium">Implement a firewall</p>
                    <p className="text-sm text-muted-foreground">
                      Configure a firewall to restrict access to only necessary services and trusted IP addresses.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-2">
                  <CheckCircle2 className="h-5 w-5 text-green-500 mt-0.5" />
                  <div>
                    <p className="font-medium">Regular scanning</p>
                    <p className="text-sm text-muted-foreground">
                      Perform regular security scans to identify new vulnerabilities as they emerge.
                    </p>
                  </div>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </CardContent>
    </Card>
  )
}

