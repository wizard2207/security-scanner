"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { ScanResults } from "@/components/scan-results"
import { scanNetwork } from "@/actions/scan-actions"
import type { ScanResultType } from "@/types/scan-types"
import { AlertCircle, Loader2 } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export function ScannerInterface() {
  const [target, setTarget] = useState("")
  const [portRange, setPortRange] = useState([1, 1000])
  const [timeout, setTimeout] = useState(2000)
  const [scanDeep, setScanDeep] = useState(false)
  const [isScanning, setIsScanning] = useState(false)
  const [results, setResults] = useState<ScanResultType | null>(null)
  const [error, setError] = useState<string | null>(null)

  const handleScan = async () => {
    if (!target) {
      setError("Please enter a target IP address or domain")
      return
    }

    setError(null)
    setIsScanning(true)
    setResults(null)

    try {
      const scanResults = await scanNetwork({
        target,
        portRange,
        timeout,
        scanDeep,
      })
      setResults(scanResults)
    } catch (err) {
      setError("An error occurred during the scan. Please try again.")
      console.error(err)
    } finally {
      setIsScanning(false)
    }
  }

  return (
    <div className="grid gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Scan Configuration</CardTitle>
          <CardDescription>Configure your network scan parameters</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="basic">
            <TabsList className="mb-4">
              <TabsTrigger value="basic">Basic Scan</TabsTrigger>
              <TabsTrigger value="advanced">Advanced Options</TabsTrigger>
            </TabsList>

            <TabsContent value="basic" className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="target">Target IP or Domain</Label>
                <Input
                  id="target"
                  placeholder="e.g., 192.168.1.1 or example.com"
                  value={target}
                  onChange={(e) => setTarget(e.target.value)}
                />
              </div>

              <div className="flex items-center justify-between">
                <Button onClick={handleScan} disabled={isScanning} className="w-full">
                  {isScanning ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Scanning...
                    </>
                  ) : (
                    "Start Scan"
                  )}
                </Button>
              </div>
            </TabsContent>

            <TabsContent value="advanced" className="space-y-4">
              <div className="grid gap-2">
                <Label htmlFor="target-adv">Target IP or Domain</Label>
                <Input
                  id="target-adv"
                  placeholder="e.g., 192.168.1.1 or example.com"
                  value={target}
                  onChange={(e) => setTarget(e.target.value)}
                />
              </div>

              <div className="grid gap-2">
                <div className="flex justify-between">
                  <Label>
                    Port Range: {portRange[0]} - {portRange[1]}
                  </Label>
                </div>
                <Slider
                  defaultValue={[1, 1000]}
                  max={65535}
                  step={1}
                  value={portRange}
                  onValueChange={setPortRange}
                  className="py-4"
                />
              </div>

              <div className="grid gap-2">
                <Label>Timeout: {timeout}ms</Label>
                <Slider
                  defaultValue={[2000]}
                  min={500}
                  max={10000}
                  step={100}
                  value={[timeout]}
                  onValueChange={(value) => setTimeout(value[0])}
                />
              </div>

              <div className="flex items-center space-x-2">
                <Switch id="deep-scan" checked={scanDeep} onCheckedChange={setScanDeep} />
                <Label htmlFor="deep-scan">Deep Scan (Service Detection)</Label>
              </div>

              <Button onClick={handleScan} disabled={isScanning} className="w-full">
                {isScanning ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Scanning...
                  </>
                ) : (
                  "Start Advanced Scan"
                )}
              </Button>
            </TabsContent>
          </Tabs>

          {error && (
            <Alert variant="destructive" className="mt-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
        </CardContent>
      </Card>

      {results && <ScanResults results={results} />}
    </div>
  )
}

