export interface PortInfo {
  port: number
  service?: string
  version?: string
}

export interface Vulnerability {
  name: string
  severity: string
  description: string
  affectedPorts?: number[]
  recommendation?: string
}

export interface HostInfo {
  type?: string
  os?: string
}

export interface ScanResultType {
  target: string
  timestamp: number
  scanDuration: number
  openPorts: PortInfo[]
  vulnerabilities: Vulnerability[]
  hostInfo: HostInfo
}

